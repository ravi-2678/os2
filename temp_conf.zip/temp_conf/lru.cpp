#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	
	vector <int> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	int k;
    cin>>k;

    vector <int> res;
    map<int,int> mp;
    int hit = 0;
    int ind;

    for(int i=0;i<n;i++)
    {
    	int g = a[i];
    	mp[g]++;
    	if(mp[g]==1)
    	res.push_back(g);
        else
        hit++;

        if(res.size()==k)
        {
        	ind = i+1;
        	break;
        }
    }
    
    for(auto i:res) cout << i << " ";
    cout << endl;

    for(int i=ind;i<n;i++)
    {
    	auto it = find(res.begin(),res.end(),a[i]);
    	if(it==res.end())
    	{
    		int g = -1;
    		int f = 0;
    		for(int j=0;j<i;j++)
    		{
       			for(int p=0;p<k;p++)
    			{
    				if(a[j]==res[p])
    				{
    					g = p;
    					f = 1;
    					break;
    				}
    			}
    			if(f==1) break;
    		}
    		res[g] = a[i];
    	}
    	else
    	hit++;

        for(auto i:res) cout << i << " ";
        cout << endl;
    }

    cout << hit << endl;
}