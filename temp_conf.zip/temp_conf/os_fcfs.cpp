#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	vector <int> at(n);
	for(int i=0;i<n;i++) cin>>at[i];

	vector <int> bt(n);
    for(int i=0;i<n;i++) cin>>bt[i];

    vector<int> f(n,0);
    vector<int> ct(n);

    int t = 0;
    int fc = 0;
    while(fc<n)
    {
    	int k = -1;
    	int m = INT_MAX;
    	for(int j=0;j<n;j++)
    	{
    		if(at[j]<=t and f[j]!=-1)
    		{
    			if(at[j]<m)
    			{
    				m = at[j];
    				k = j;
    			}
    		}
    	}

    	if(k!=-1)
    	{
    		ct[k] = t+bt[k];
    		f[k] = -1;
    		t = ct[k];
    		fc++;
    	}
    	else
    	{
    		t++;
    	}
    }

    for(auto i:ct)
    cout << i << " ";
    cout << endl;

    for(int i=0;i<n;i++)
    {
        int tat = ct[i]-at[i];
        int wt =  tat - bt[i];

        cout << ct[i] << " " << tat << " " << wt << endl;
    }
}