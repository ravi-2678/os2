#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	vector<int> b(n);
	for(int i=0;i<n;i++) cin>>b[i];

	int m;
    cin>>m;
    vector<int> p(n);
    for(int i=0;i<m;i++) cin>>p[i];

    vector <int> f(n);
    vector <int> res(n,-1);
    for(int i=0;i<m;i++)
    {
    	int j = 0;
    	for(j=0;j<n;j++)
    	{
    		if(p[i]<=b[j] and f[j]!=-1)
    		{
    			cout << i+1 <<" position proccess placed in "<< j+1 << " position block" << endl;
    			f[j] = -1;
    			res[j] = i+1;
    			break;
    		}
    	}
    	if(j==n)
    	{
    		cout << "process not placed" << endl;
    	}
    }

    for(auto i:res)
    cout << i << " ";
    cout << endl;
}