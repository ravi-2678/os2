#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	vector<int> a(n);
	for(int i=0;i<n;i++) cin>>a[i];

	int head ;
    cin>>head;
    int x = head;

    int sum = 0;
    vector<int> f(n);
    vector <pair<int,int> > res;

    int fc = 0;
    while(fc<n)
    {
    	int k = -1;
    	int m = INT_MAX;
    	for(int j=0;j<n;j++)
    	{
            if(f[j]!=-1)
            {
            	int seek = abs(x-a[j]);
            	if(seek<m)
            	{
            		m = seek;
            		k = j;
            	}
            }
    	}

    	if(k!=-1)
    	{
    		sum += abs(x-a[k]);
    		res.push_back({x,a[k]});
    		x = a[k];
    		
    		f[k] = -1;
    		fc++;

    		
    	}
    }

    cout << sum << endl;

    for(auto i:res)
    cout << i.first<<"-"<<i.second<<endl;

}