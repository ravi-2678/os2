#include <bits/stdc++.h>
using namespace std;

int main()
{
	int track;
	cin>>track;
	track--;
	int direction;
	cin>>direction;

	int n;
	cin>>n;
	vector <int> a(n);
	for(int i=0;i<n;i++) cin>>a[i];

	int head;
    cin >> head;

	sort(a.begin(),a.end());
    
    int sum = 0;
    if(direction == 1)
    {
        sum += abs(track-head) + (track-a[0]);
    }
    else
    {
    	sum += head+a[n-1];
    }

    cout << sum << endl;

    
}