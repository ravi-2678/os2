#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;

	vector <int> at(n);
	for(int i=0;i<n;i++) cin>>at[i];

	vector <int> bt(n);
    for(int i=0;i<n;i++) cin>>bt[i];

    vector <int> ct(n);
    vector <int> f(n);

    int t = 0;
    int fc = 0;
    while(fc<n)
    {
    	int k = -1;
    	int m = INT_MAX;
    	int aT;
    	for(int j=0;j<n;j++)
    	{
    		if(at[j]<=t and f[j]!=-1)
    		{
    			if(bt[j]<m)
    		    {
    		    	m = bt[j];
    		    	k = j;
    		    	aT = at[j];
    		    }
    		    else if(bt[j]==m)
    		    {
                   if(at[j]<aT)
                   {
                   	  k = j;
                   	  aT = at[j];
                   }
    		    }
    		}
    	}

    	if(k!=-1)
    	{
    		ct[k] = t+bt[k];
    		t = ct[k];
    		fc ++;
    		f[k] = -1;
    	}
    	else
    	t++;
    }

    for(auto i:ct)
    cout << i << " ";
    cout << endl;
}