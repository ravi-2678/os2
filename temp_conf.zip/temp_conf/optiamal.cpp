#include <bits/stdc++.h>
using namespace std;

int index(vector <int> res)
{
	int c = *min_element(res.begin(),res.end());
	int n = res.size();
	if(c==-1) 
	{
        for(int i=0;i<n;i++)
        if(res[i]==-1) return i;
	}

	int m = *max_element(res.begin(),res.end());
	for(int i=0;i<n;i++)
	{
		if(res[i]==m) return i;

	}
	return -1;

}
int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++) cin>>a[i];
	int k;
    cin>>k;

    vector <int>res;
    map<int,int> mp;
    int hit = 0;
    int ind ;

    for(int i=0;i<n;i++)
    {
    	int g = a[i];
    	mp[g]++;
    	if(mp[g]==1)
    	res.push_back(g);
        else
        hit++;

        if(res.size()==k)
        {
        	ind = i+1;
        	break;
        }
    }

    for(auto i:res) cout << i << " ";
    cout << endl;

    for(int i=ind;i<n;i++)
    {
    	auto it = find(res.begin(),res.end(),a[i]);
    	if(it==res.end())
    	{
    		vector<int> f(k,-1);
    		for(int j=i+1;j<n;j++)
    		{
    			for(int p=0;p<k;p++)
    			{
    				if(res[p]==a[j] and f[p]==-1)
    				f[p] = j;
    			}
    		}
    		int g = index(f);
    		res[g] = a[i];
    	}
    	else
    	hit++;

        for(auto i:res) cout << i << " ";
        cout << endl;
    }
    cout << hit << endl;
}