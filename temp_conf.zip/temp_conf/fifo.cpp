#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++) cin>>a[i];

	int k;
    cin>>k;

    map<int,int> mp;
    vector <int> frame;

    int hit = 0;
    int pf = 0;
    
    int ind ;
    for(int i=0;i<n;i++)
    {
        int g = a[i];
        mp[g]++;

        if( mp[g]==1 )
        frame.push_back(a[i]);
        else
        hit++;

        if(frame.size()==k)
        {
            ind = i+1;
            break;
        }
    }

    for(auto i:frame) cout << i << " ";
    cout << endl;

    int j=0;
    int c=0;
    for(int i=ind;i<n;i++)
    {
        auto it = find(frame.begin(),frame.end(),a[i]);
        if(it==frame.end())
        {
            if(c<k)
            {
                frame[j] = a[i];
                j++;
                c++;
            }
            else
            {
                j = 0;
                c = 0;
                frame[j] = a[i];
                j++;
                c++;
            }
        }
        else
        hit++;

        for(auto i:frame)
        cout << i <<" ";
        cout << endl;
    }

    cout << "hit:"<< hit << endl;
    cout << "page fault: "<< n-hit << endl;
}